function pay() {
    var MOP = document.getElementById("sell").value;
    document.getElementById("MOP").innerHTML = MOP;

}
